package com.example.recyclerview_app.view

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerview_app.R
import com.example.recyclerview_app.model.Restaurants

class RestaurantAdapter(private val restaurants : List<Restaurants>): RecyclerView.Adapter<RestaurantAdapter.RestaurantViewHolder>(){

    class RestaurantViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val RName = itemView.findViewById<TextView>(R.id.rName)
        val RAddress = itemView.findViewById<TextView>(R.id.rAddress)
        val RSpeciality = itemView.findViewById<TextView>(R.id.rSpeciality)
        val RImage = itemView.findViewById<ImageView>(R.id.rImg)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RestaurantViewHolder {
        val view : View = LayoutInflater.from(parent.context).inflate(R.layout.layout_row_type, parent, false)
        return RestaurantViewHolder(view)
    }

    override fun getItemCount(): Int = restaurants.size

    override fun onBindViewHolder(holder: RestaurantViewHolder, position: Int) {
        holder.RName.text = restaurants[position].name
        holder.RAddress.text = restaurants[position].address
        holder.RSpeciality.text = restaurants[position].speciality
        holder.RImage.setImageResource(restaurants[position].img)
    }

}