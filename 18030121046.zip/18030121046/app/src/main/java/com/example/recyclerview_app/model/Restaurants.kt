package com.example.recyclerview_app.model

data class Restaurants(
    val img : Int,
    val name: String,
    val address: String,
    val speciality: String,
    val rating: Int
)