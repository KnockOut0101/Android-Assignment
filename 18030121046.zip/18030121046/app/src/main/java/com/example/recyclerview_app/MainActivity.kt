  package com.example.recyclerview_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.observe
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerview_app.view.RestaurantAdapter
import com.example.recyclerview_app.viewmodel.RestaurantViewModel

  class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView : RecyclerView
    private lateinit var  restaurantViewModel: RestaurantViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        restaurantViewModel = ViewModelProvider(this).get(RestaurantViewModel::class.java)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        recyclerView.addItemDecoration(DividerItemDecoration(recyclerView.context,(LinearLayoutManager(this).orientation)))

        restaurantViewModel.users.observe(this){
            it?.let {
                    newRestaurantList ->
                recyclerView.adapter = RestaurantAdapter(newRestaurantList)
            }
        }

        restaurantViewModel.fetchData()

    }


}