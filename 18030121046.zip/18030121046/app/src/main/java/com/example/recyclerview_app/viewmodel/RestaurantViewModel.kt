package com.example.recyclerview_app.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.recyclerview_app.R
import com.example.recyclerview_app.model.Restaurants

class RestaurantViewModel: ViewModel() {
    val users = MutableLiveData<List<Restaurants>>()

    fun fetchData(){

        val restaurantsList = ArrayList<Restaurants>()

        restaurantsList.add(Restaurants(R.drawable.bukhara,"Karim’s", "Delhi", "Malai Kebab", 2))
        restaurantsList.add(Restaurants(R.drawable.cafelota,"Cafe Lota", "Delhi", "Coffee", 3))
        restaurantsList.add(Restaurants(R.drawable.artusiristorante,"Sagar Ratna", "Delhi", "South Indian", 5))
        restaurantsList.add(Restaurants(R.drawable.leo,"Leo's Pizzeria", "Delhi", "Pizza & Pastas", 3))
        restaurantsList.add(Restaurants(R.drawable.greenr,"Andhra Bhavan", "Delhi", "Mutton Curry", 1))
        restaurantsList.add(Restaurants(R.drawable.townhall,"Town Hall", "Delhi", "Mutton Biryani", 3))
        restaurantsList.add(Restaurants(R.drawable.olive,"Olive Bar & Kitchen", "Delhi", "Cajun Chicken", 2))
        restaurantsList.add(Restaurants(R.drawable.indianaccent,"Indian Accent", "Delhi", "Traditional Indian ", 5))

        users.value = restaurantsList
    }
}